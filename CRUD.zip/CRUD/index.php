<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="dark-mode.css">

    <title>Membuat CRUD</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<style>
    body { 
        background-image: url('1.jpg');
        background-attachment: fixed;
        background-size: 100% 100%;
        font-family:"Arial";
    }
    [data-theme="dark"] {
  background-color: #111 !important;
  color: #eee;
}

a{
            color:orange;
            text-decoration: none;
        }  
        a:hover{
            color:green;
        }
    </style>
<body>
<div class="container">
    <div class="judul">
        <br><br>
        <footer class="rounded bg-dark text-light">
    <center><h1> Membuat CRUD Dengan PHP Dan MySQL</h1>
        <h2> Menampilkan Data Dari Database</h2></center>
</footer>
</div>
<?php
if(isset($_GET['pesan'])){
    $pesan = $_GET['pesan'];
    if($pesan == "input"){
        echo "*Data berhasil di input.";
    }else if ($pesan == "update"){
        echo "*Data berhasil di update.";
    }else if ($pesan == "delete"){
        echo "*Data berhasil di hapus.";
    }
}
?>
<div class="container">
<a class="btn btn-success btn-sm" href="SAYA.html">About Me</a>
<a class="tombol btn btn-sm btn-primary" href="input.php">+ Tambah Data Baru</a></div>
<p>
</p>
<footer class="rounded bg-dark text-light">
    <h3 class="text-center">Data User</h3>
</div>
</footer>
<div class="container">
<table border="1" class="table table-striped table-bordered table-dark text-light">
    <tr>
        <th>No</th>
        <th>Nama</th>
        <th>Alamat</th>
        <th>Pekerjaan</th>
        <th>Opsi</th>
</tr>
<?php
include "koneksi.php";
$query_mysql = mysqli_query($koneksi,"select * from user1");
$nomor = 1;
while($data = mysqli_fetch_array($query_mysql)){
?>
<tr>
    <td><?php echo $nomor++; ?></td>
    <td><?php echo $data['nama'];?></td>
    <td><?php echo $data['alamat'];?></td>
    <td><?php echo $data['pekerjaan'];?></td>
</td>
<td>
<a class="edit" href="edit.php?id=<?php echo $data['Id'];?>">Edit |</a>
<a class="hapus" href="hapus.php?id=<?php echo $data['Id'];?>">Hapus</a>
</td>
</tr>
<?php } ?>
</table>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br>
<footer class="rounded bg-dark text-light">
    <h3 class="text-end">©. Leiivan です。</h3>
</div>
</div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>
</html>
