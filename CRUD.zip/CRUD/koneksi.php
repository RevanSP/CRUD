<?php
$koneksi = mysqli_connect("localhost","root","","program_sederhana_leiivan");
if (mysqli_connect_errno()){
    echo"Koneksi database gagal: " .mysqli_connect_error();
}
?>