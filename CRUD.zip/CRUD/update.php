<?php
include 'koneksi.php';
$Id = $_POST['Id'];
$nama = $_POST['nama'];
$alamat = $_POST['alamat'];
$pekerjaan = $_POST['pekerjaan'];
mysqli_query($koneksi,"UPDATE user1 SET nama='$nama',alamat='$alamat', pekerjaan='$pekerjaan' WHERE Id='$Id'");
header("location:index.php?pesan=update");
?>